<?php

namespace App\Http\Controllers;

use App\Exports\EventExport;
use App\Models\AgentMaster;
use App\Models\Category;
use App\Models\Event;
use App\Models\MasterBooking;
use App\Models\PenddingBookingsMaster;
use App\Models\SeatConfig;
use App\Services\EventKeyGeneratorService;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Storage;
use DB;
use Maatwebsite\Excel\Facades\Excel;

class EventController extends Controller
{
    protected $keyGenerator;

    public function __construct(EventKeyGeneratorService $keyGenerator)
    {
        $this->keyGenerator = $keyGenerator;
    }

    //kinjal
    // public function FeatureEvent()
    // {

    //     $today = now()->toDateString(); // Current date in 'YYYY-MM-DD' format

    //     $events = Event::where('status', 1)
    //         ->where('event_feature', 1)
    //         ->where('date_range', '>=', $today)
    //         ->with([
    //             'tickets' => function ($query) {
    //                 $query->select('id', 'event_id', 'price', 'sale_price', 'sale', 'booking_not_open', 'sold_out');
    //             },
    //             'user' => function ($query) {
    //                 $query->select('id', 'name', 'organisation');
    //             }
    //         ])
    //         ->latest()
    //         ->get();
    //     // return response()->json(['status' => 'true', 'events' => $events], 200);
    //     foreach ($events as $event) {
    //         $event->lowest_ticket_price = $event->tickets->min('price');
    //         $event->lowest_sale_price = $event->tickets->min('sale_price');
    //         $event->on_sale = $event->tickets->contains('sale', "true");
    //         $event->booking_close = $event->tickets->every(fn($ticket) => $ticket->sold_out === true || $ticket->sold_out === 'true');
    //         $event->booking_not_start = $event->tickets->every(fn($ticket) => $ticket->donation === true || $ticket->donation === 'true');
    //         unset($event->tickets);
    //     }

    //     return response()->json(['status' => 'true', 'events' => $events], 200);
    // }

    public function FeatureEvent()
    {
        $today = Carbon::today();


        $query = Event::where('status', "1")->where('event_feature', 1)->with([
            'tickets' => function ($query) {
                $query->select('id', 'event_id', 'price', 'sale_price', 'sale', 'booking_not_open', 'sold_out', 'fast_filling');
            },
            'user' => function ($query) {
                $query->select('id', 'name', 'organisation'); // Include fields you want to retrieve
            }
        ]);
        $events = $query->get(['id', 'name', 'thumbnail', 'event_key', 'date_range', 'category', 'city', 'user_id']);
        // Check if any events are fetched
        if ($events->isEmpty()) {
            return response()->json(['status' => true, 'message' => 'No events found with status 1'], 200);
        }

        // Initialize arrays for ongoing and future events
        $ongoingEvents = collect();
        $futureEvents = collect();

        // Categorize events
        foreach ($events as $event) {
            $dates = array_map('trim', explode(',', $event->date_range));
            // Handle single date or date range
            if (count($dates) === 1) {
                $startDate = Carbon::parse($dates[0]);
                $endDate = $startDate; // Set endDate the same as startDate for single date
            } else {
                [$startDate, $endDate] = array_map('trim', $dates);
                $startDate = Carbon::parse($startDate);
                $endDate = Carbon::parse($endDate);
            }

            if ($today->between($startDate, $endDate)) {
                $ongoingEvents->push($event);
            } elseif ($today->lt($startDate)) {
                $futureEvents->push($event);
            }
        }

        // Sort events by start date
        $ongoingEvents = $ongoingEvents->sortBy(fn($event) => Carbon::parse(explode(',', $event->date_range)[0]));
        $futureEvents = $futureEvents->sortBy(fn($event) => Carbon::parse(explode(',', $event->date_range)[0]));

        // Combine ongoing and future events
        $sortedEvents = $ongoingEvents->merge($futureEvents);

        // Process events for additional fields
        $sortedEvents->transform(function ($event) {
            $event->lowest_ticket_price = $event->tickets->min('price');
            $event->lowest_sale_price = $event->tickets->min('sale_price');
            $event->on_sale = $event->tickets->contains('sale', 1);
            $event->fast_filling = $event->tickets->contains('fast_filling', 1);
            $event->booking_close = $event->tickets->every(fn($ticket) => $ticket->sold_out === 1);
            $event->booking_not_start = $event->tickets->every(fn($ticket) => $ticket->booking_not_open === 1);
            unset($event->tickets);
            return $event;
        });

        return response()->json(['status' => 'true', 'events' => $sortedEvents], 200);
    }

    public function indexUsingDB(Request $request)
    {
        $today = Carbon::today();

        // Fetch events with status 1 and calculate necessary fields
        $events = Event::where('status', "1")
            ->leftJoin('tickets', 'events.id', '=', 'tickets.event_id')
            ->select(
                'events.id',
                'events.name',
                'events.thumbnail',
                'events.event_key',
                'events.date_range',
                DB::raw('MIN(tickets.price) as lowest_ticket_price'),
                DB::raw('MIN(tickets.sale_price) as lowest_sale_price'),
                DB::raw('MAX(tickets.sale = "true") as on_sale')
            )
            ->groupBy(
                'events.id',
                'events.name',
                'events.thumbnail',
                'events.event_key',
                'events.date_range'
            )
            ->get();

        // Check if any events are fetched
        if ($events->isEmpty()) {
            return response()->json(['status' => true, 'message' => 'No events found with status 1'], 200);
        }

        // Initialize arrays for ongoing and future events
        $ongoingEvents = collect();
        $futureEvents = collect();

        // Categorize events
        foreach ($events as $event) {
            [$startDate, $endDate] = array_map('trim', explode(',', $event->date_range));
            $startDate = Carbon::parse($startDate);
            $endDate = Carbon::parse($endDate);

            if ($today->between($startDate, $endDate)) {
                $ongoingEvents->push($event);
            } elseif ($today->lt($startDate)) {
                $futureEvents->push($event);
            }
        }

        // Sort events by start date
        $ongoingEvents = $ongoingEvents->sortBy(fn($event) => Carbon::parse(explode(',', $event->date_range)[0]));
        $futureEvents = $futureEvents->sortBy(fn($event) => Carbon::parse(explode(',', $event->date_range)[0]));

        // Combine ongoing and future events
        $sortedEvents = $ongoingEvents->merge($futureEvents);

        return response()->json(['status' => true, 'events' => $sortedEvents], 200);
    }

    public function index(Request $request)
    {
        $today = Carbon::today();
        $categoryTitle = $request->category;
        $bookingType = $request->type;

        $query = Event::where('status', "1")->with([
            'tickets' => function ($query) {
                $query->select('id', 'event_id', 'price', 'sale_price', 'sale', 'booking_not_open', 'sold_out');
            },
            'user' => function ($query) {
                $query->select('id', 'name', 'organisation'); // Include fields you want to retrieve
            }
        ]);
        $bookingTypeFields = [
            'online' => 'online_booking',
            'agent' => 'agent_booking',
            'pos' => 'pos_booking',
            'complimentary' => 'complimentary_booking',
            'exhibition' => 'exhibition_booking',
            'amusement' => 'amusement_booking',
        ];

        if ($bookingType && isset($bookingTypeFields[$bookingType])) {
            $query->where($bookingTypeFields[$bookingType], 1);
        }

        if ($categoryTitle) {
            $category = Category::where('title', $categoryTitle)->select('id')->first();
            if ($category) {
                $events = $query->where('category', $category->id)
                    ->get(['id', 'name', 'thumbnail', 'event_key', 'date_range', 'category', 'city', 'user_id']);
            } else {
                return response()->json(['status' => false, 'message' => 'Category not found'], 404);
            }
        } else {
            $events = $query->get(['id', 'name', 'thumbnail', 'event_key', 'date_range', 'category', 'city', 'user_id']);
        }
        // Check if any events are fetched
        if ($events->isEmpty()) {
            return response()->json(['status' => true, 'message' => 'No events found with status 1'], 200);
        }

        // Initialize arrays for ongoing and future events
        $ongoingEvents = collect();
        $futureEvents = collect();

        // Categorize events
        foreach ($events as $event) {
            $dates = array_map('trim', explode(',', $event->date_range));
            // Handle single date or date range
            if (count($dates) === 1) {
                $startDate = Carbon::parse($dates[0]);
                $endDate = $startDate; // Set endDate the same as startDate for single date
            } else {
                [$startDate, $endDate] = array_map('trim', $dates);
                $startDate = Carbon::parse($startDate);
                $endDate = Carbon::parse($endDate);
            }

            if ($today->between($startDate, $endDate)) {
                $ongoingEvents->push($event);
            } elseif ($today->lt($startDate)) {
                $futureEvents->push($event);
            }
        }

        // Sort events by start date
        $ongoingEvents = $ongoingEvents->sortBy(fn($event) => Carbon::parse(explode(',', $event->date_range)[0]));
        $futureEvents = $futureEvents->sortBy(fn($event) => Carbon::parse(explode(',', $event->date_range)[0]));

        // Combine ongoing and future events
        $sortedEvents = $ongoingEvents->merge($futureEvents);

        // Process events for additional fields
        $sortedEvents->transform(function ($event) {
            $event->lowest_ticket_price = $event->tickets->min('price');
            $event->lowest_sale_price = $event->tickets->min('sale_price');
            // $event->on_sale = $event->tickets->contains('sale', "true");
            // $event->booking_close = $event->tickets->every(fn($ticket) => $ticket->sold_out === true || $ticket->sold_out === 'true');
            // $event->booking_not_start = $event->tickets->every(fn($ticket) => $ticket->booking_not_open === true || $ticket->booking_not_open === 'true');
            $event->on_sale = $event->tickets->contains('sale', 1);
            $event->booking_close = $event->tickets->every(fn($ticket) => $ticket->sold_out === 1);
            $event->booking_not_start = $event->tickets->every(fn($ticket) => $ticket->booking_not_open === 1);
            unset($event->tickets); // Remove tickets relation if not needed in the response
            return $event;
        });

        return response()->json(['status' => true, 'events' => $sortedEvents], 200);
    }

    public function junk()
    {
        $today = Carbon::today()->toDateString();
        $events = Event::onlyTrashed()->where('status', 1)
            ->where(function ($query) use ($today) {
                // Check for single-day events or multi-day events
                $query->where(function ($subQuery) use ($today) {
                    // Single-day events
                    $subQuery->whereRaw('? = DATE_FORMAT(SUBSTRING_INDEX(date_range, ",", 1), "%Y-%m-%d")', [$today])
                        ->orWhereRaw('? < DATE_FORMAT(SUBSTRING_INDEX(date_range, ",", 1), "%Y-%m-%d")', [$today]);
                })
                    ->orWhere(function ($subQuery) use ($today) {
                        // Multi-day events
                        $subQuery->whereRaw('? <= DATE_FORMAT(SUBSTRING_INDEX(date_range, ",", -1), "%Y-%m-%d")', [$today]);
                    });
            })
            ->get();
        foreach ($events as $event) {
            // Get the minimum ticket price for the event
            $event->lowest_ticket_price = $event->tickets->min('price');
            $event->lowest_sale_price = $event->tickets->min('sale_price');
        }
        return response()->json(['status' => true, 'events' => $events], 200);
    }

    public function eventList($id)
    {
        $loggedInUser = Auth::user()->load('reportingUser');
        $today = Carbon::today()->toDateString();

        if ($loggedInUser->hasRole('Admin')) {
            $eventsQuery = Event::query();
        } else {
            $reporting_user = $loggedInUser->reportingUser;

            $reporting_userAdmin = $reporting_user->roles->pluck('name')->first();

            if ($reporting_userAdmin =='Admin') {
                // return response()->json($reporting_userAdmin);
                $eventsQuery = Event::where('user_id', $loggedInUser->id);

            } else {
                $eventsQuery = Event::where('user_id', $loggedInUser->id)
                ->orWhere('user_id', $reporting_user->id);

            }
        }
        $events = $eventsQuery
        ->select('id','user_id','category','name','date_range','created_at','event_type','event_key')
        ->with([
            'tickets:id',
            'user:id,name',
            'Category:id,title'
        ])->get();

        // Process events
        foreach ($events as $event) {
            $dateRange = explode(',', $event->date_range);

            if (count($dateRange) == 1) {
                // Single day event
                $eventDate = Carbon::parse(trim($dateRange[0]));

                if ($today == $eventDate->toDateString()) {
                    $event->event_status = 1; // Ongoing
                } elseif ($today < $eventDate->toDateString()) {
                    $event->event_status = 2; // Upcoming
                } else {
                    $event->event_status = 3; // Past
                }
            } else {
                // Multi-day event
                $startDate = Carbon::parse(trim($dateRange[0]));
                $endDate = Carbon::parse(trim($dateRange[1]));

                if ($today >= $startDate->toDateString() && $today <= $endDate->toDateString()) {
                    $event->event_status = 1; // Ongoing
                } elseif ($today < $startDate->toDateString()) {
                    $event->event_status = 2; // Upcoming
                } else {
                    $event->event_status = 3; // Past
                }
            }

            // Get the lowest ticket price
            $event->lowest_ticket_price = $event->tickets->min('price') ?? 0;
            $event->lowest_sale_price = $event->tickets->min('sale_price') ?? 0;
        }

        return response()->json(['status' => true, 'events' => $events], 200);
    }
    // public function eventList($id)
    // {
    //     $loggedInUser = Auth::user();
    //     $today = Carbon::today()->toDateString();

    //     if ($loggedInUser->hasRole('Admin')) {
    //         $eventsQuery = Event::query();
    //     } else {
    //         $reporting_user = $loggedInUser->reporting_user;

    //         $eventsQuery = Event::where('user_id', $loggedInUser->id)
    //             ->orWhere('user_id', $reporting_user);
    //     }

    //     $events = $eventsQuery
    //     ->select('id','user_id','category','name','date_range','created_at','event_type','event_key')
    //     ->with([
    //         'tickets:id',
    //         'user:id,name',
    //         'Category:id,title'
    //     ])->get();

    //     // Process events
    //     foreach ($events as $event) {
    //         $dateRange = explode(',', $event->date_range);

    //         if (count($dateRange) == 1) {
    //             // Single day event
    //             $eventDate = Carbon::parse(trim($dateRange[0]));

    //             if ($today == $eventDate->toDateString()) {
    //                 $event->event_status = 1; // Ongoing
    //             } elseif ($today < $eventDate->toDateString()) {
    //                 $event->event_status = 2; // Upcoming
    //             } else {
    //                 $event->event_status = 3; // Past
    //             }
    //         } else {
    //             // Multi-day event
    //             $startDate = Carbon::parse(trim($dateRange[0]));
    //             $endDate = Carbon::parse(trim($dateRange[1]));

    //             if ($today >= $startDate->toDateString() && $today <= $endDate->toDateString()) {
    //                 $event->event_status = 1; // Ongoing
    //             } elseif ($today < $startDate->toDateString()) {
    //                 $event->event_status = 2; // Upcoming
    //             } else {
    //                 $event->event_status = 3; // Past
    //             }
    //         }

    //         // Get the lowest ticket price
    //         $event->lowest_ticket_price = $event->tickets->min('price') ?? 0;
    //         $event->lowest_sale_price = $event->tickets->min('sale_price') ?? 0;
    //     }

    //     return response()->json(['status' => true, 'events' => $events], 200);
    // }

    public function eventByUser(Request $request,$id)
    {
        $bookingType = $request->type;

        $loggedInUser = Auth::user();
        $today = Carbon::today()->toDateString();
        //where('status', "1")->
        // Admins see all events
        if ($loggedInUser->hasRole('Admin')) {
            $eventsQuery = Event::with('tickets', 'user');
        } else {
            // Non-admin users see only their events
            $reporting_user = $loggedInUser->reporting_user;
            $eventsQuery = Event::where('user_id', $id)
                ->orWhere('user_id', $reporting_user)
                ->with('tickets', 'user');
        }

        if ($bookingType) {
            $bookingField = match ($bookingType) {
                'online' => 'online_booking',
                'agent' => 'agent_booking',
                'pos' => 'pos_booking',
                'complimentary' => 'complimentary_booking',
                'exhibition' => 'exhibition_booking',
                'amusement' => 'amusement_booking',
            };

            if ($bookingField) {
                $eventsQuery->where($bookingField, 1);
            }
        }

        // Filter out finished events
        $events = $eventsQuery->get()->filter(function ($event) use ($today) {
            $dateRange = explode(',', $event->date_range);

            if (count($dateRange) == 1) {
                // Single-day event
                $eventDate = Carbon::parse(trim($dateRange[0]));
                return $eventDate->toDateString() >= $today;
            } else {
                // Multi-day event
                $endDate = Carbon::parse(trim($dateRange[1]));
                return $endDate->toDateString() >= $today;
            }
        });
        // Process events
        foreach ($events as $event) {
            $dateRange = explode(',', $event->date_range);

            if (count($dateRange) == 1) {
                // Single day event
                $eventDate = Carbon::parse(trim($dateRange[0]));

                if ($today == $eventDate->toDateString()) {
                    $event->event_status = 1; // Ongoing
                } elseif ($today < $eventDate->toDateString()) {
                    $event->event_status = 2; // Upcoming
                } else {
                    $event->event_status = 3; // Past
                }
            } else {
                // Multi-day event
                $startDate = Carbon::parse(trim($dateRange[0]));
                $endDate = Carbon::parse(trim($dateRange[1]));

                if ($today >= $startDate->toDateString() && $today <= $endDate->toDateString()) {
                    $event->event_status = 1; // Ongoing
                } elseif ($today < $startDate->toDateString()) {
                    $event->event_status = 2; // Upcoming
                } else {
                    $event->event_status = 3; // Past
                }
            }

            // Get the lowest ticket price
            $event->lowest_ticket_price = $event->tickets->min('price') ?? 0;
            $event->lowest_sale_price = $event->tickets->min('sale_price') ?? 0;
        }

        return response()->json(['status' => true, 'events' => $events->values()], 200);
    }

    public function info($id)
    {
        try {
            // Assuming the user is authenticated and you have access to the user object
            $user = Auth::user();
            $isAdmin = $user->hasRole('Admin');
            $isScanner = $user->hasRole('Scanner');

            // Get the current date
            $currentDate = Carbon::today()->toDateString();

            // Fetch all active events based on user role and event date
            $events = Event::with(['tickets.bookings', 'tickets.agentBooking', 'tickets.posBookings'])
                ->where(function ($query) use ($user, $currentDate, $isAdmin, $isScanner) {
                    if ($isAdmin) {
                        // Admins see all events that start today
                        $query->whereRaw('SUBSTRING_INDEX(date_range, ",", 1) = ?', [$currentDate]);
                    } else if ($isScanner) {
                        // Scanners see events assigned to their reporting user that start today
                        $query->where('user_id', $user->reporting_user);
                        // ->whereRaw('SUBSTRING_INDEX(date_range, ",", 1) = ?', [$currentDate]);
                        $query->where('date_range', 'LIKE', "%$currentDate%")
                            ->orWhereRaw("? BETWEEN SUBSTRING_INDEX(date_range, ',', 1) AND SUBSTRING_INDEX(date_range, ',', -1)", [$currentDate]);
                    } else {
                        // Non-admin, non-scanner users see their own events that start today
                        $query->where('user_id', $user->id)
                            ->whereRaw('SUBSTRING_INDEX(date_range, ",", 1) = ?', [$currentDate]);
                    }
                })
                ->get();

            // If no active events are found, return a response indicating so
            if ($events->isEmpty()) {
                return response()->json(['status' => false, 'message' => 'No active events found', $user->reportingUser], 404);
            }

            $eventData = [];

            foreach ($events as $event) {
                // Initialize counts
                $totalBookings = 0;
                $remainingBookings = 0;
                $checkedBookings = 0;

                // Loop through each ticket and its bookings to calculate the counts
                foreach ($event->tickets as $ticket) {
                    $totalBookings += $ticket->bookings->count();
                    $totalBookings += $ticket->agentBooking->count();
                    $totalBookings += $ticket->posBookings->sum('quantity');

                    // Calculate remaining bookings (status 0)
                    $remainingBookings += $ticket->bookings->where('status', 0)->count();
                    $remainingBookings += $ticket->agentBooking->where('status', 0)->count();
                    $remainingBookings += $ticket->posBookings->where('status', 0)->sum('quantity');

                    // Calculate checked bookings (status 1)
                    $checkedBookings += $ticket->bookings->where('status', 1)->count();
                    $checkedBookings += $ticket->agentBooking->where('status', 1)->count();
                    $checkedBookings += $ticket->posBookings->where('status', 1)->sum('quantity');
                }

                // Determine the category based on the event_type
                $category = $event->event_type == 'season' ? 'Seasonal' : 'Daily';

                // Prepare the event data
                $eventData[] = [
                    'event' => $event,
                    'total_bookings' => $totalBookings,
                    'remaining_bookings' => $remainingBookings,
                    'checked_bookings' => $checkedBookings,
                    'category' => $category,
                ];
            }

            return response()->json(['status' => true, 'data' => $eventData], 201);
        } catch (\Exception $e) {
            // Return an error response if something goes wrong
            return response()->json(['status' => false, 'message' => 'An error occurred: ' . $e->getMessage()], 500);
        }
    }

    public function create(Request $request)
    {

        try {
            // return response()->json(['event'=>$request->all()], 200);
            $event = new Event();
            $event->user_id = $request->user_id;
            $event->category = $request->category;
            $event->name = $request->name;
            $event->country = $request->country;
            $event->state = $request->state;
            $event->city = $request->city;
            $event->address = $request->address;
            $eventKey = $this->keyGenerator->generateKey();
            $event->event_key = $eventKey;
            $event->short_info = $request->short_info;
            $event->description = $request->description;
            $event->offline_payment_instruction = $request->offline_payment_instruction;
            //  $event->customer_care_number = $request->customer_care_number;
            $event->event_feature = $request->event_feature;
            $event->house_full = $request->house_full;
            $event->sms_otp_checkout = $request->sms_otp_checkout;
            $event->rfid_required = $request->rfid_required;
            $event->multi_scan = $request->multi_scan;
            $event->online_att_sug = $request->online_att_sug;
            $event->offline_att_sug = $request->offline_att_sug;
            $event->scan_detail = $request->scan_detail;
            $event->online_booking = $request->online_booking;
            $event->agent_booking = $request->agent_booking;
            $event->pos_booking = $request->pos_booking;
            $event->complimentary_booking = $request->complimentary_booking;
            $event->exhibition_booking = $request->exhibition_booking;
            $event->amusement_booking = $request->amusement_booking;
            $event->ticket_system = $request->ticket_system;


            // if ($request->hasFile('layout_image')) {
            //     $eventName = strtolower(str_replace(' ', '_', $event->name));
            //     $eventDirectory = "event/" . str_replace(' ', '_', strtolower($request->name));

            //     $layoutFolder = 'layout_image';
            //     $file = $request->file('layout_image');
            //     $fileName = 'get-your-ticket-' . uniqid() . '_' . $file->getClientOriginalName();
            //     $storedLayoutPath = $this->storeFile($file, "{$eventDirectory}/{$layoutFolder}/{$fileName}");
            //     $event->layout_image = $storedLayoutPath;
            // }

            if ($request->hasFile('layout_image')) {
                $eventName = strtolower(str_replace(' ', '_', $event->name));
                $eventDirectory = "event/" . str_replace(' ', '_', strtolower($request->name));
            
                $layoutFolder = 'layout_image';
                $file = $request->file('layout_image');
                $fileName = 'get-your-ticket-' . uniqid() . '_' . $file->getClientOriginalName();
                
                // Ensure the stored path doesn't duplicate the filename
                $storedLayoutPath = $this->storeFile($file, "{$eventDirectory}/{$layoutFolder}", $fileName);
                
                $event->layout_image = $storedLayoutPath;
            }
            

            $event->save();
            return response()->json(['status' => true, 'message' => 'Event Created Successfully', 'event' => $event], 201);
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => 'Failed to create Event', 'error' => $e->getMessage()], 500);
        }
    }

    public function store(Request $request)
    {
        //
    }

    public function edit(string $id)
    {
        $event = Event::with([
            'tickets',
            'user',
            'Category:id,title'
        ])->where('event_key', $id)->firstOrFail();
        // $event = Event::with('tickets', 'user','Category')->where('event_key', $id)->firstOrFail();
        $event->lowest_ticket_price = $event->tickets->min('price');
        $event->lowest_sale_price = $event->tickets->min('sale_price');
        $event->on_sale = $event->tickets->contains('sale', "true");
        $event->booking_close = $event->tickets->every(fn($ticket) => $ticket->sold_out === true || $ticket->sold_out === 'true');
        $event->booking_not_start = $event->tickets->every(fn($ticket) => $ticket->donation === true || $ticket->donation === 'true');

        return response()->json(['status' => true, 'events' => $event], 200);
    }

    public function update(Request $request, string $id)
    {
        try {
            $event = Event::where('event_key', $id)->firstOrFail();

            if ($request->has('category')) {
                $request->merge(['category' => strtolower($request->category)]);
            }

            $event->fill($request->only([
                'user_id',
                'category',
                'name',
                'country',
                'state',
                'city',
                'address',
                'short_info',
                'description',
                'offline_payment_instruction',
                //  'customer_care_number',
                'event_feature',
                'status',
                'house_full',
                'sms_otp_checkout',
                'date_range',
                'start_time',
                'end_time',
                'event_type',
                'map_code',
                'youtube_url',
                'multi_qr',
                'status',
                'meta_title',
                'meta_tag',
                'meta_description',
                'meta_keyword',
                'rfid_required',
                'multi_scan',
                'online_att_sug',
                'offline_att_sug',
                'scan_detail',
                'online_booking',
                'agent_booking',
                'pos_booking',
                'complimentary_booking',
                'exhibition_booking',
                'amusement_booking',
                'ticket_system'

            ]));

            if ($request->ticket_terms) {
                $event->ticket_terms = $request->ticket_terms;
            }
            if ($request->ticket_template_id) {
                $event->ticket_template_id = $request->ticket_template_id;
            }
            // if ($request->hasFile('thumbnail')) {
            //     $eventName = strtolower(str_replace(' ', '_', $event->name));
            //     $eventDirectory = "event/" . str_replace(' ', '_', strtolower($request->name));

            //     $thumbnailFolder = 'thumbnail';
            //     $file = $request->file('thumbnail');
            //     $fileName = 'get-your-ticket-' . uniqid() . '_' . $file->getClientOriginalName();
            //     $storedThumbnailPath = $this->storeFile($file, "{$eventDirectory}/{$thumbnailFolder}/{$fileName}");
            //     $event->thumbnail = $storedThumbnailPath;
            // }

            if ($request->hasFile('thumbnail')) {
                $categoryFolder = str_replace(' ', '_', strtolower($request->category));
                $originalName = $request->file('thumbnail')->getClientOriginalName();
                $fileName = 'get-your-ticket-' . time() . '-' . $originalName;
                
                // Store new image using storeFile method
                $filePath = $this->storeFile($request->file('thumbnail'), "thumbnail$categoryFolder", 'public');
                $event->thumbnail = $filePath;
            }

            if ($request->hasFile('layout_image')) {
                $eventName = strtolower(str_replace(' ', '_', $event->name));
                $eventDirectory = "event/" . str_replace(' ', '_', strtolower($request->name));

                $layoutFolder = 'layout_image';
                $file = $request->file('layout_image');
                $fileName = 'get-your-ticket-' . uniqid() . '_' . $file->getClientOriginalName();
                $storedLayoutPath = $this->storeFile($file, "{$eventDirectory}/{$layoutFolder}/{$fileName}");
                $event->layout_image = $storedLayoutPath;
            }



            $imagePaths = [];
            for ($i = 1; $i <= 4; $i++) {
                if ($request->hasFile("images_" . $i)) {
                    $image = $request->file("images_" . $i);
                    if ($image instanceof \Illuminate\Http\UploadedFile) {
                        $fileName = 'get-your-ticket-' . uniqid() . '_' . $image->getClientOriginalName();
                        $eventDirectory = 'event/' . str_replace(' ', '_', strtolower($request->name));
                        $folder = 'gallery';
                        $path = $this->storeFile($image, "{$eventDirectory}/{$folder}/{$fileName}");
                        $imagePaths[] = $path;
                    }
                }
            }


            $event->images = $imagePaths;

            $event->save();
            $event->load('tickets');
            return response()->json(['status' => true, 'message' => 'Event Updated Successfully', 'event' => $event], 201);
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => 'Failed to Event user', 'error' => $e->getMessage()], 500);
        }
    }

    private function storeFile($file, $folder, $disk = 'public')
    {
        $filename = uniqid() . '_' . $file->getClientOriginalName();
        $path = $file->storeAs('uploads/' . $folder, $filename, $disk);
        return Storage::disk($disk)->url($path);
    }

    // public function destroy(string $id)
    // {
    //     $event = Event::findOrFail($id);
    //     if ($event) {
    //         $event->delete();
    //         return response()->json(['status' => true, 'message' => 'Event deleted successfully'], 200);
    //     }
    // }

    public function destroy(string $id)
    {
        $event = Event::findOrFail($id);

        if ($event) {

            $deletedBookingIds = [];
            $deletedAgentBookingIds = [];
            $deletedPenddingBookingIds = [];

            foreach ($event->tickets as $ticket) {

                $deletedBookingIds = array_merge($deletedBookingIds, $ticket->bookings()->pluck('id')->toArray());
                $deletedAgentBookingIds = array_merge($deletedAgentBookingIds, $ticket->agentBooking()->pluck('id')->toArray());
                $deletedPenddingBookingIds = array_merge($deletedPenddingBookingIds, $ticket->PenddingBookings()->pluck('id')->toArray());

                $ticket->bookings()->delete();
                $ticket->agentBooking()->delete();
                $ticket->PenddingBookings()->delete();
                $ticket->complimentaryBookings()->delete();
                $ticket->posBookings()->delete();
            }

            $event->tickets()->delete();

            if (!empty($deletedBookingIds)) {
                MasterBooking::whereJsonContains('booking_id', $deletedBookingIds)->update(['deleted_at' => now()]);
            }
            if (!empty($deletedAgentBookingIds)) {
                AgentMaster::whereJsonContains('booking_id', $deletedAgentBookingIds)->update(['deleted_at' => now()]);
            }
            if (!empty($deletedPenddingBookingIds)) {
                PenddingBookingsMaster::whereJsonContains('booking_id', $deletedPenddingBookingIds)->update(['deleted_at' => now()]);
            }

            $event->delete();

            return response()->json([
                'status' => true,
                'message' => 'Event and all related data deleted successfully'
            ], 200);
        }
    }

    public function export(Request $request)
    {

        $organizer = $request->input('organizer');
        $category = $request->input('category');
        $eventType = $request->input('event_type');
        $status = $request->input('status');
        $eventDates = $request->input('date_range') ? explode(',', $request->input('date_range')) : null;
        $dates = $request->input('date') ? explode(',', $request->input('date')) : null;

        $query = Event::query();

        if ($request->has('organizer')) {
            $query->where('user_id', $organizer);
        }

        if ($request->has('category')) {
            $query->where('category', $category);
        }

        if ($eventType) {
            $query->where('event_type', $eventType);
        }

        if ($request->has('status')) {
            $query->where('status', $status);
        }

        if ($eventDates) {
            if (count($eventDates) === 1) {
                $singleDate = Carbon::parse($eventDates[0])->toDateString();
                $query->whereDate('date_range', $singleDate);
            } elseif (count($eventDates) === 2) {
                $startDate = Carbon::parse($eventDates[0])->startOfDay();
                $endDate = Carbon::parse($eventDates[1])->endOfDay();
                $query->whereBetween('date_range', [$startDate, $endDate]);
            }
        }

        if ($dates) {
            if (count($dates) === 1) {
                $singleDate = Carbon::parse($dates[0])->toDateString();
                $query->whereDate('created_at', $singleDate);
            } elseif (count($dates) === 2) {
                $startDate = Carbon::parse($dates[0])->startOfDay();
                $endDate = Carbon::parse($dates[1])->endOfDay();
                $query->whereBetween('created_at', [$startDate, $endDate]);
            }
        }

        $events = $query->get();
        return Excel::download(new EventExport($events), 'events_export.xlsx');
    }
}

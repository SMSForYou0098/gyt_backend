<?php

namespace App\Http\Controllers;

use App\Models\CashfreeConfig;
use App\Models\User;
use App\Services\BookingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use App\Services\CashfreeService;
class CashfreeController extends Controller
{

    protected $bookingService;
    protected $cashfreeService;

    public function __construct(BookingService $bookingService , CashfreeService $cashfreeService) 
    {
        $this->bookingService = $bookingService;
        $this->cashfreeService = $cashfreeService;
    }

    private function generateEncryptedSessionId()
    {
        $originalSessionId = Str::random(32);
        $encryptedSessionId = encrypt($originalSessionId);

        return [
            'original' => $originalSessionId,
            'encrypted' => $encryptedSessionId
        ];
    }
    public function initiatePayment(Request $request){
     {   
        $orderId = 'ORD_' . Str::random(10);

        $getSession = $this->generateEncryptedSessionId();
        $session = $getSession['original'];
        $sessionId = $getSession['encrypted'];
        $amount = $request->amount;
        $response = $this->cashfreeService->createOrderAndGetPaymentUrl(
            $orderId,
            $amount,
            auth()->id(),
            auth()->user()->name,
            auth()->user()->email,
            $request->phone,
            $session
        );

        return response()->json($response);
    }
}

    // public function initiatePayment(Request $request)
    // {
    //     try {
    //         // Get organizer or fallback to admin config
    //         $config = CashfreeConfig::where('user_id', $request->organizer_id)->first();
    //         $adminConfig = CashfreeConfig::where('user_id', User::role('Admin')->value('id'))->first();

    //         // $env = $config->env ?? $adminConfig->env;
    //         $env = 'test'; // Default to test environment for this example
    //         $txnid = 'TXN_' . time() . '_' . Str::random(6);
    //         $appId = 'TEST107498867fb87814e7962565f53a68894701';
    //         $secretKey = 'cfsk_ma_test_11a1594c63ea4a86022cb181e15ece79_f0aa7ff6';
    //         // $appId = $config->app_id ?? $adminConfig->app_id;
    //         // $secretKey = $config->secret_key ?? $adminConfig->secret_key;
    //         $baseUrl = ($env === 'test') 
    //             ? 'https://sandbox.cashfree.com' 
    //             : 'https://api.cashfree.com';

    //         $getSession = $this->generateEncryptedSessionId();
    //         $session = $getSession['original'];
    //         $sessionId = $getSession['encrypted'];
    //         $orderId = 'CF_' . time() . '_' . random_int(100000, 999999);

    //         $gateway = 'cashfree';
    //         $request->merge(['gateway' => $gateway]);

    //         // Prepare payload
    //         $payload = [
    //             "order_id" => $orderId,
    //             "order_amount" => number_format((float)$request->amount, 2, '.', ''),
    //             "order_currency" => "INR",
    //             "order_note" => $request->productinfo ?? 'Ticket Booking',
    //             "customer_details" => [
    //                 "customer_id" => (string) $request->user_id,
    //                 "customer_name" => $request->firstname ?? 'Customer',
    //                 "customer_email" => $request->email,
    //                 "customer_phone" => $request->phone,
    //             ],
    //             "order_meta" => [
    //                 "return_url" => url('/api/payment-response/' . $gateway . '/' . $request->event_id . '/' . $sessionId . '?status={order_status}&category=' . urlencode($request->category)),
    //             ]
    //         ];

    //         // Validate required fields
    //         if (empty($request->amount) || $request->amount <= 0) {
    //             return response()->json(['status' => false, 'message' => 'Invalid amount'], 400);
    //         }
    //         if (empty($request->email)) {
    //             return response()->json(['status' => false, 'message' => 'Email is required'], 400);
    //         }
    //         if (empty($request->phone)) {
    //             return response()->json(['status' => false, 'message' => 'Phone is required'], 400);
    //         }
    //         //return $payload;
    //         // Create Cashfree order
    //         $response = Http::withHeaders([
    //             "accept" => "application/json",
    //             "content-type" => "application/json",
    //             "x-client-id" => $appId,
    //             "x-client-secret" => $secretKey,
    //             "x-api-version" => "2022-09-01"
    //         ])->post("$baseUrl/pg/orders", $payload);
    //        // return $response->json();
    //         if (!$response->successful()) {
    //             $errorDetails = $response->json();
    //             return response()->json([
    //                 'status' => false, 
    //                 'message' => 'Failed to create Cashfree order',
    //                 'error_details' => $errorDetails,
    //                 'status_code' => $response->status()
    //             ], 500);
    //         }

    //         $paymentResponse = $response->json();
    //         $paymentLink = $paymentResponse['payments']['url'] ?? null;

    //         // Store pending booking
    //         $bookings = $this->bookingService->storePendingBookings($request, $session, $orderId, $gateway);

    //         if ($bookings['status'] === true) {
    //             return response()->json([
    //                 'status' => true,
    //                 'order_id' => $orderId,
    //                 // 'url' => $paymentResponse['payment_link'],
    //                 'payment_response' => $paymentResponse
    //             ]);
    //         }

    //         return response()->json(['status' => false, 'message' => 'Booking creation failed'], 400);

    //     } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
    //         return response()->json(['status' => false, 'message' => 'Configuration not found'], 404);
    //     } catch (\Throwable $e) {
    //         return response()->json(['status' => false, 'message' => $e->getMessage()], 500);
    //     }
    // }
}